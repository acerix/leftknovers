
ALTER TABLE notification_preferences ADD COLUMN notification_email TEXT;

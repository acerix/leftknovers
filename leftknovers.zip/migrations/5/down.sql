
DROP INDEX idx_food_items_created_at;
DROP INDEX idx_food_items_status;
ALTER TABLE food_items DROP COLUMN notes;

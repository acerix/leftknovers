
ALTER TABLE notification_preferences DROP COLUMN notification_email;


ALTER TABLE food_items DROP COLUMN user_id;

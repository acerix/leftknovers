
DROP INDEX idx_food_items_consumed;
DROP INDEX idx_food_items_expiration;
DROP TABLE food_items;

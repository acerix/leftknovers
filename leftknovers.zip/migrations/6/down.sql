
DROP INDEX idx_friendships_user2;
DROP INDEX idx_friendships_user1;
DROP INDEX idx_friend_invitations_recipient;
DROP INDEX idx_friend_invitations_token;
DROP TABLE friendships;
DROP TABLE friend_invitations;

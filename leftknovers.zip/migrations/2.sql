
ALTER TABLE food_items ADD COLUMN user_id TEXT;
